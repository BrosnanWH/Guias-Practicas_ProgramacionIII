﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CRUDSitioDeLosToursFechas
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            if (txtFechaInicio.Text == "")
            {
                txtFechaInicio.Text = Calendar1.SelectedDate.ToString();
            }
        
            else
            {
                txtFechaFin.Text = Calendar1.SelectedDate.ToString();
            }

        }

        protected void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtFechaInicio.Text = string.Empty;
            txtFechaFin.Text = string.Empty;
        }
    }
}