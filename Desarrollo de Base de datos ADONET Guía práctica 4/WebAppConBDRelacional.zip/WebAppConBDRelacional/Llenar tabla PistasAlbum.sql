﻿-- Datos para Michael Jackson - Thriller (1982)
INSERT INTO PistasAlbum (NumeroAlbum, NumeroPista, NombrePista) VALUES
(1, 1, 'Wanna Be Startin Somethin'),
(1, 2, 'Baby Be Mine'),
(1, 3, 'The Girl Is Mine'),
(1, 4, 'Thriller'),
(1, 5, 'Beat It'),
(1, 6, 'Billie Jean'),
(1, 7, 'Human Nature'),
(1, 8, 'P.Y.T. (Pretty Young Thing)'),
(1, 9, 'The Lady in My Life');

-- Datos para Daddy Yankee - Barrio Fino (2004)
INSERT INTO PistasAlbum (NumeroAlbum, NumeroPista, NombrePista) VALUES
(2, 1, 'Intro'),
(2, 2, 'King Daddy'),
(2, 3, 'Dale Caliente'),
(2, 4, 'Gasolina'),
(2, 5, 'Like You'),
(2, 6, 'No Me Dejes Solo'),
(2, 7, 'Lo Que Pasó, Pasó'),
(2, 8, 'Salud y Vida'),
(2, 9, 'Cuentame'),
(2, 10, 'Intermedio');

-- Datos para Luis Miguel - Romance (1991)
INSERT INTO PistasAlbum (NumeroAlbum, NumeroPista, NombrePista) VALUES
(3, 1, 'No Me Platiques Más'),
(3, 2, 'Usted'),
(3, 3, 'La Puerta'),
(3, 4, 'La Barca'),
(3, 5, 'Inolvidable'),
(3, 6, 'La Mentira'),
(3, 7, 'Sabor a Mí'),
(3, 8, 'Contigo en la Distancia'),
(3, 9, 'Mucho Corazón'),
(3, 10, 'Nosotros'),
(3, 11, 'Yo Sé Que Volverás'),
(3, 12, 'Noche de Ronda');
